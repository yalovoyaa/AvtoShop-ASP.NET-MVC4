﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AvtoShop.Domain.Abstract;
using AvtoShop.Domain.Entities;
using AvtoShop.WebUI.Models;

namespace AvtoShop.WebUI.Controllers
{
    public class ProductController : Controller
    {
        // GET: /Product/

        private IProductRepository repository;

        public int PageSize = 5;

        public ProductController(IProductRepository productRepository)
        {
            this.repository = productRepository;
        }

        public ViewResult List(string category, int page = 1)
        {
            ProductsListViewModel viewModel = new ProductsListViewModel
            {
                Products = repository.Products
                .Where(p => category == null || p.Type == category)
                .OrderBy(p => p.ProductID)
                .Skip((page - 1) * PageSize)
                .Take(PageSize),
                PagingInfo = new PagingInfo
                {
                    CurrentPage = page,
                    ItemsPerPage = PageSize,
                    TotalItems = category == null ? //если категория выбрана, мы возвращаем количество товаров в этой категории, 
                        repository.Products.Count() : //если нет, мы возвращаем общее количество товаров.
                        repository.Products.Where(e => e.Type == category).Count()
                },
                CurrentCategory = category
            };
            return View(viewModel);
        }

        public FileContentResult GetImage(int productId)
        {
            Product prod = repository.Products.FirstOrDefault(p => p.ProductID == productId);
            if (prod != null)
            {
                return File(prod.ImageData, prod.ImageMimeType);
            }
            else
            {
                return null;
            }
        }
    }
}