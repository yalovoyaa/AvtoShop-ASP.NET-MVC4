﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AvtoShop.Domain.Entities;

namespace AvtoShop.WebUI.Binders
{
    public class CartModelBinder : IModelBinder
    {
        private const string sessionKey = "Cart";

        public object BindModel(ControllerContext controllerContext, ModelBindingContext bindingContext)
        {
            // получение содержимого корзины из сессии
            Cart cart = (Cart)controllerContext.HttpContext.Session[sessionKey];

            // если не было данных в сессии - создаем корзину
            if (cart == null)
            {
                cart = new Cart();
                controllerContext.HttpContext.Session[sessionKey] = cart;
            }
            // возвращаем корзину с товарами
            return cart;
        }
    }
}