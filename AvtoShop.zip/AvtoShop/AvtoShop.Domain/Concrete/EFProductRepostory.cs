﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AvtoShop.Domain.Abstract;
using AvtoShop.Domain.Entities;
using System.Linq;

namespace AvtoShop.Domain.Concrete
{
    public class EFProductRepostory : IProductRepository
    {
        private EFDbContext context = new EFDbContext();

        public IQueryable<Product> Products
        {
            get { return context.Products; }
        }

        public void SaveProduct(Product product)
        {
            if (product.ProductID == 0)
            {
                context.Products.Add(product);
            }
            else
            {
                Product dbEntry = context.Products.Find(product.ProductID);
                if (dbEntry != null)
                {
                    dbEntry.Model = product.Model;
                    dbEntry.Color = product.Color;
                    dbEntry.Year = product.Year;
                    dbEntry.Type = product.Type;
                    dbEntry.Engine = product.Engine;
                    dbEntry.Transmission = product.Transmission;
                    dbEntry.Price = product.Price;
                    if //((dbEntry.ImageData == null && dbEntry.ImageMimeType == null) ||
                       // (dbEntry.ImageData != null && dbEntry.ImageMimeType != null) ||
                        (product.ImageData != null)
                    {
                        dbEntry.ImageData = product.ImageData;
                    }
 
                    dbEntry.ImageMimeType = product.ImageMimeType;
                }
            }
            context.SaveChanges();
        }

        public Product DeleteProduct(int productId)
        {
            Product dbEntry = context.Products.Find(productId);
            if (dbEntry != null)
            {
                context.Products.Remove(dbEntry);
                context.SaveChanges();
            }
            return dbEntry;
        }
    }
}
