﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;

namespace AvtoShop.Domain.Entities
{
    public class Product
    {
        [HiddenInput(DisplayValue = false)]
        public int ProductID { get; set; }

        [Required(ErrorMessage = "Пожалуйста, введите модель автомобиля")]
        public string Model { get; set; }

        [Required(ErrorMessage = "Пожалуйста, укажите цвет автомобиля")]
        public string Color { get; set; }

        [Required]
        [Range(1900, int.MaxValue, ErrorMessage = "Пожалуйста, введите год выпуска автомобиля")]
        public int Year { get; set; }

        [Required(ErrorMessage = "Пожалуйста, укажите тип кузова")]
        public string Type { get; set; }

        [Required]
        [Range(100, int.MaxValue, ErrorMessage = "Пожалуйста, укажите объем двигателя")]
        public int Engine { get; set; }

        [Required(ErrorMessage = "Пожалуйста, укажите тип коробки передач")]
        public string Transmission { get; set; }

        [Required]
        [Range(0.01, double.MaxValue, ErrorMessage = "Пожалуйста, введите положительное значение цены")]
        public decimal Price { get; set; }

        public byte[] ImageData { get; set; }

        [HiddenInput(DisplayValue = false)]
        public string ImageMimeType { get; set; }
    }
}
